## AUTHOR : Picarrow

# ...
tellraw @a ["",{"color":"green","text":"[Hit Match]"},{"color":"red","text":" Error;"},{"color":"gray","text":" Func hit_match:_pulse/victim must be called from a hit context."}]
function hit_match:error/_
